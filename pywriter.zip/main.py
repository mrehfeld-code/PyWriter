from pywriter import write

write("Hello world!")
